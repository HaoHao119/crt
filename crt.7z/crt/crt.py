from crtsh import crtshAPI
import json
import sys, getopt

# 定义子域名
str_Remove_Repeat = []

# url
str_url = ''
# 保存文本
str_text = ''


# 获取子域名
def get_url(url):
    global str_Remove_Repeat
    # 解析网站的编码
    str_crt = json.dumps(crtshAPI().search(url))

    # 存储JSON
    json_crt = json.loads(str_crt)

    # json长度
    json_L = len(json_crt)

    # 定义List :name_value
    list_name_value = []

    i = 0
    # 遍历添加子域名
    while i < json_L:
        # print(json_crt[i]['common_name'])
        # 将子域名写入数组
        list_name_value.append(json_crt[i]['common_name'])
        i = i + 1

    # 去重复
    str_Remove_Repeat = {}.fromkeys(list_name_value).keys()
    # 遍历打印子域名
    for i in str_Remove_Repeat:
        print(i)
    print('end')


# 将子域名写入到TXT里面
def get_txt(txt):
    # 写入TXT文档
    with open(txt, "w") as f:
        for i in str_Remove_Repeat:
            f.write(i + "\n")


def main(argv):
    try:
        opts, args = getopt.getopt(argv, "hu:t:")
    except getopt.GetoptError:
        print('-u <url> -t <text.txt')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('-u <url> -t <text.txt')
            sys.exit()

        # -U 扫描子域名
        elif opt in ("-u", "--url"):
            str_url = arg
            get_url(str_url)
        # -T 保存文本
        elif opt in ("-t", "--text"):
            str_text = arg
            get_txt(str_text)


if __name__ == "__main__":
    main(sys.argv[1:])
