from crtsh import crtshAPI
import json

# 解析网站的编码
str_crt = json.dumps(crtshAPI().search('58.com'))

# print(str_crt)
# print('----------------------------------------')
# 存储JSON
json_crt = json.loads(str_crt)

# json长度
json_L = len(json_crt)

# 定义List :name_value
list_name_value = []

i = 0
# 遍历添加子域名
while i < json_L:
    # print(json_crt[i]['common_name'])
    # 将子域名写入数组
    list_name_value.append(json_crt[i]['common_name']+"\n")
    i = i + 1

# print(list_name_value)
# print("----------------------------------------------")

# 去重复
str_Remove_Repeat = {}.fromkeys(list_name_value).keys()
print(list(str_Remove_Repeat))

# 写入TXT文档
with open("D:/douban.txt", "w") as f:
    for i in str_Remove_Repeat:
        f.write(i)

print("end")